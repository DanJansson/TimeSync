Push-Location $PSScriptRoot

#Replace domain name and import WMI Filters
(Get-Content "domaincontrollernonpdc.mof") -Replace "contoso.local", $ENV:USERDNSDOMAIN | Set-Content domaincontrollernonpdc.mof
(Get-Content "domaincontrollerpdc.mof") -Replace "contoso.local", $ENV:USERDNSDOMAIN | Set-Content domaincontrollerpdc.mof
mofcomp -N:root\Policy domaincontrollernonpdc.mof
mofcomp -N:root\Policy domaincontrollerpdc.mof


$GPdomain = New-Object Microsoft.GroupPolicy.GPDomain
$SearchFilter = New-Object Microsoft.GroupPolicy.GPSearchCriteria
$allWmiFilters = $GPdomain.SearchWmiFilters($SearchFilter)

$PDCFilter = $allWmiFilters | ?{$_.Name -eq "Domain Controller PDC"}
$NonPDCFilter = $allWmiFilters | ?{$_.Name -eq "Domain Controller non-PDC"}

#Get DC OU
$OU ="OU=Domain Controllers," + ([System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain().GetDirectoryEntry() | select -ExpandProperty DistinguishedName) 
$domainname = $ENV:USERDNSDOMAIN

#GPO Names
$PDCGPOName = "Domain Controller Timesync PDC"
$NonPDCGPOName = "Domain Controller Timesync non-PDC"

#Create GPOs
$PDCGPO = New-GPO -Name $PDCGPOName
$NONPDCGPO = New-GPO -Name $NonPDCGPOName

#Create links | out-null needed?
New-GPLink -Name $PDCGPOName -Target "$OU" 
New-GPLink -Name $NonPDCGPOName -Target "$OU"

#Set WMI filters
$PDCGPO.WmiFilter = $PDCFilter

$NONPDCGPO.WmiFilter = $NonPDCFilter 

$Path = $pwd.path

if (!(Test-Path $Path\GPOBackup -PathType Container)) {
    if (Test-Path $Path\GPOBackup.zip -PathType Leaf) {
        Expand-Archive $Path\GPOBackup.zip -DestinationPath $Path
    }
    else {
        Write-Error "Could not find $Path\GPOBackup folder or $Path\GPOBackup.zip." -Verbose
        Exit
    }
}

$GPOs = Get-GPO -All
$GPOBackups = Get-ChildItem -Path $Path\GPOBackup -Directory
foreach ($GPO in $GPOs){
    $GPOBackup = $GPOBackups | Where-Object Name -eq $GPO.DisplayName
    if ($GPOBackup) {
        Import-GPO -Path $GPOBackup.fullname -BackupGpoName $GPOBackup.Name -Verbose -TargetName $GPOBackup.Name -ErrorAction SilentlyContinue
    }
}



Pop-Location